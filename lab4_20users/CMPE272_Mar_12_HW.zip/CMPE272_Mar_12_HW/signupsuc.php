<html>
<head>
	<h2>Successfully created!</h2><br>
</head>
<body>
	<a href="index.php">Go back to login in</a><br>
</body>
</html>
