<html>
<head>
	<style>
	</style>
</head>
</body>
	<?php
		echo "<h1> Products </h1><br><br>";
	?>
	<a href=last5.php>See 5 Products you just viewed</a><br><br><br>
	<?php
		$filename="Gaming K360.png";
		echo "<img src='$filename' alt= '$filename' />";
	?>
	<br><a href=gk360.php>Gaming RGB K360</a><br><br><br><br>
	<?php
		$filename="Gaming K380.png";
		echo "<img src='$filename' alt= '$filename' />";
	?>
	<br><a href=gk380.php>Gaming RGB K380</a><br><br><br><br>
	<?php
		$filename="Gaming K660.png";
		echo "<img src='$filename' alt= '$filename' />";
	?>
	<br><a href=gk660.php>Gaming RGB K660</a><br><br><br><br>
	<?php
		$filename="Gaming X820.png";
		echo "<img src='$filename' alt= '$filename' />";
	?>
	<br><a href=gx820.php>Gaming RGB X820</a><br><br><br><br>
	<?php
		$filename="Gaming X980L.png";
		echo "<img src='$filename' alt= '$filename' />";
	?>
	<br><br><a href=gx980l.php>Gaming RGB X980L</a><br><br><br><br>
	<?php
		$filename="Gaming M380.png";
		echo "<img src='$filename' alt= '$filename' />";
	?>
	<br><br><a href=gm380.php>Gaming RGB M380</a><br><br><br><br><br>
	<?php
		$filename="Gaming M480.png";
		echo "<img src='$filename' alt= '$filename' />";
	?>
	<br><br><a href=gm480.php>Gaming RGB M480</a><br><br><br><br><br>
	<?php
		$filename="Gaming M550.png";
		echo "<img src='$filename' alt= '$filename' />";
	?>
	<br><a href=gm550.php>Gaming M550</a><br><br><br><br>
	<?php
		$filename="Gaming Y320.png";
		echo "<img src='$filename' alt= '$filename' />";
	?>
	<br><br><a href=gy320.php>Gaming Y320</a><br><br><br><br>
	<?php
		$filename="Gaming K320 Mini.png";
		echo "<img src='$filename' alt= '$filename' />";
	?>
	<br><br><a href=gk320m.php>Gaming K320 Mini</a><br><br><br><br>
</body>
</html>